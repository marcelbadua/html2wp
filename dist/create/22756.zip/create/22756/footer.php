
      <hr>

      <footer>
        <p>&copy; Company 2014</p>
      </footer>
    </div> <!-- /container -->        <script src="//ajax.googleapis.com/ajax/libs/jquery/1.11.0/jquery.min.js"></script>
        <script>window.jQuery || document.write('<script src="<?php bloginfo("template_url"); ?>/js/vendor/jquery-1.11.0.min.js"><\/script>')</script>

        <script src="<?php bloginfo("template_url"); ?>/js/vendor/bootstrap.min.js"></script>

        <script src="<?php bloginfo("template_url"); ?>/js/theme.js"></script>


    </body>
</html>
